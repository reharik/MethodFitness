--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public."unpaidAppointments" DROP CONSTRAINT "unpaidAppointments_pkey";
ALTER TABLE ONLY public.trainer DROP CONSTRAINT trainer_pkey;
ALTER TABLE ONLY public."trainerPayments" DROP CONSTRAINT "trainerPayments_pkey";
ALTER TABLE ONLY public."trainerPaymentDetails" DROP CONSTRAINT "trainerPaymentDetails_pkey";
ALTER TABLE ONLY public."trainerLoggedIn" DROP CONSTRAINT "trainerLoggedIn_pkey";
ALTER TABLE ONLY public.states DROP CONSTRAINT states_pkey;
ALTER TABLE ONLY public."sessionsPurchased" DROP CONSTRAINT "sessionsPurchased_pkey";
ALTER TABLE ONLY public.purchases DROP CONSTRAINT purchases_pkey;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public."lastProcessedPosition" DROP CONSTRAINT "lastProcessedPosition_pkey";
ALTER TABLE ONLY public."lastProcessedPosition" DROP CONSTRAINT "lastProcessedPosition_handlerType_key";
ALTER TABLE ONLY public.client DROP CONSTRAINT client_pkey;
ALTER TABLE ONLY public.appointment DROP CONSTRAINT appointment_pkey;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public."user";
DROP TABLE public."unpaidAppointments";
DROP TABLE public."trainerPayments";
DROP TABLE public."trainerPaymentDetails";
DROP TABLE public."trainerLoggedIn";
DROP TABLE public.trainer;
DROP TABLE public.states;
DROP TABLE public."sessionsPurchased";
DROP TABLE public.purchases;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP TABLE public."lastProcessedPosition";
DROP TABLE public.client;
DROP TABLE public.appointment;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE appointment (
    id uuid NOT NULL,
    trainer uuid NOT NULL,
    date date NOT NULL,
    document jsonb
);


ALTER TABLE appointment OWNER TO methodfitness;

--
-- Name: client; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE client (
    id uuid NOT NULL,
    archived boolean DEFAULT false,
    document jsonb
);


ALTER TABLE client OWNER TO methodfitness;

--
-- Name: lastProcessedPosition; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "lastProcessedPosition" (
    id uuid NOT NULL,
    "commitPosition" bigint,
    "preparePosition" bigint,
    "handlerType" text
);


ALTER TABLE "lastProcessedPosition" OWNER TO methodfitness;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE migrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    run_on timestamp without time zone NOT NULL
);


ALTER TABLE migrations OWNER TO methodfitness;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: methodfitness
--

CREATE SEQUENCE migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE migrations_id_seq OWNER TO methodfitness;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: methodfitness
--

ALTER SEQUENCE migrations_id_seq OWNED BY migrations.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE purchases (
    id uuid NOT NULL,
    document jsonb
);


ALTER TABLE purchases OWNER TO methodfitness;

--
-- Name: sessionsPurchased; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "sessionsPurchased" (
    id uuid NOT NULL,
    meta jsonb,
    document jsonb
);


ALTER TABLE "sessionsPurchased" OWNER TO methodfitness;

--
-- Name: states; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE states (
    id uuid NOT NULL,
    document jsonb
);


ALTER TABLE states OWNER TO methodfitness;

--
-- Name: trainer; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE trainer (
    id uuid NOT NULL,
    archived boolean DEFAULT false,
    document jsonb
);


ALTER TABLE trainer OWNER TO methodfitness;

--
-- Name: trainerLoggedIn; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "trainerLoggedIn" (
    id uuid NOT NULL,
    document jsonb
);


ALTER TABLE "trainerLoggedIn" OWNER TO methodfitness;

--
-- Name: trainerPaymentDetails; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "trainerPaymentDetails" (
    id uuid NOT NULL,
    meta jsonb,
    document jsonb
);


ALTER TABLE "trainerPaymentDetails" OWNER TO methodfitness;

--
-- Name: trainerPayments; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "trainerPayments" (
    id uuid NOT NULL,
    meta jsonb,
    document jsonb
);


ALTER TABLE "trainerPayments" OWNER TO methodfitness;

--
-- Name: unpaidAppointments; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "unpaidAppointments" (
    id uuid NOT NULL,
    meta jsonb,
    document jsonb
);


ALTER TABLE "unpaidAppointments" OWNER TO methodfitness;

--
-- Name: user; Type: TABLE; Schema: public; Owner: methodfitness
--

CREATE TABLE "user" (
    id uuid NOT NULL,
    archived boolean DEFAULT false,
    document jsonb
);


ALTER TABLE "user" OWNER TO methodfitness;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY migrations ALTER COLUMN id SET DEFAULT nextval('migrations_id_seq'::regclass);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY appointment (id, trainer, date, document) FROM stdin;
\.
COPY appointment (id, trainer, date, document) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY client (id, archived, document) FROM stdin;
\.
COPY client (id, archived, document) FROM '$$PATH$$/2943.dat';

--
-- Data for Name: lastProcessedPosition; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "lastProcessedPosition" (id, "commitPosition", "preparePosition", "handlerType") FROM stdin;
\.
COPY "lastProcessedPosition" (id, "commitPosition", "preparePosition", "handlerType") FROM '$$PATH$$/2940.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY migrations (id, name, run_on) FROM stdin;
\.
COPY migrations (id, name, run_on) FROM '$$PATH$$/2939.dat';

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY purchases (id, document) FROM stdin;
\.
COPY purchases (id, document) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: sessionsPurchased; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "sessionsPurchased" (id, meta, document) FROM stdin;
\.
COPY "sessionsPurchased" (id, meta, document) FROM '$$PATH$$/2951.dat';

--
-- Data for Name: states; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY states (id, document) FROM stdin;
\.
COPY states (id, document) FROM '$$PATH$$/2941.dat';

--
-- Data for Name: trainer; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY trainer (id, archived, document) FROM stdin;
\.
COPY trainer (id, archived, document) FROM '$$PATH$$/2942.dat';

--
-- Data for Name: trainerLoggedIn; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "trainerLoggedIn" (id, document) FROM stdin;
\.
COPY "trainerLoggedIn" (id, document) FROM '$$PATH$$/2944.dat';

--
-- Data for Name: trainerPaymentDetails; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "trainerPaymentDetails" (id, meta, document) FROM stdin;
\.
COPY "trainerPaymentDetails" (id, meta, document) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: trainerPayments; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "trainerPayments" (id, meta, document) FROM stdin;
\.
COPY "trainerPayments" (id, meta, document) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: unpaidAppointments; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "unpaidAppointments" (id, meta, document) FROM stdin;
\.
COPY "unpaidAppointments" (id, meta, document) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: methodfitness
--

COPY "user" (id, archived, document) FROM stdin;
\.
COPY "user" (id, archived, document) FROM '$$PATH$$/2945.dat';

--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: methodfitness
--

SELECT pg_catalog.setval('migrations_id_seq', 1, true);


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: lastProcessedPosition lastProcessedPosition_handlerType_key; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "lastProcessedPosition"
    ADD CONSTRAINT "lastProcessedPosition_handlerType_key" UNIQUE ("handlerType");


--
-- Name: lastProcessedPosition lastProcessedPosition_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "lastProcessedPosition"
    ADD CONSTRAINT "lastProcessedPosition_pkey" PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: sessionsPurchased sessionsPurchased_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "sessionsPurchased"
    ADD CONSTRAINT "sessionsPurchased_pkey" PRIMARY KEY (id);


--
-- Name: states states_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY states
    ADD CONSTRAINT states_pkey PRIMARY KEY (id);


--
-- Name: trainerLoggedIn trainerLoggedIn_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "trainerLoggedIn"
    ADD CONSTRAINT "trainerLoggedIn_pkey" PRIMARY KEY (id);


--
-- Name: trainerPaymentDetails trainerPaymentDetails_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "trainerPaymentDetails"
    ADD CONSTRAINT "trainerPaymentDetails_pkey" PRIMARY KEY (id);


--
-- Name: trainerPayments trainerPayments_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "trainerPayments"
    ADD CONSTRAINT "trainerPayments_pkey" PRIMARY KEY (id);


--
-- Name: trainer trainer_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY trainer
    ADD CONSTRAINT trainer_pkey PRIMARY KEY (id);


--
-- Name: unpaidAppointments unpaidAppointments_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "unpaidAppointments"
    ADD CONSTRAINT "unpaidAppointments_pkey" PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: methodfitness
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO methodfitness;


--
-- PostgreSQL database dump complete
--

